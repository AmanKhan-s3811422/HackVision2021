# The Eternals
Project Code for HackVision 2021 - Team 4. The application an online/local homework help website written using PHP, SQL, Bootstrap, HTML and CSS.

* Test Account Login Details: Email = test@gmail.com; Password = test

# Running the code
1. Download XAMPP
2. Have this project within XAMPP as in C:\xampp\htdocs\The-Eternals-\
3. Open the Xampp Control Panel and click on 'Start' next to Apache
4. Go to: http://localhost/The-Eternals-/

# Opening & Accessing the SQLite database
1. Download SQLite Studio
2. Open SQLite Studio
3. Click on 'Database' from the navigation bar
4. From the drop-down, click 'Add a database'
5. Under the 'File' lable or next to the file field, click on the 'folder' icon
6. Locate database.db and select it and click 'open'

# Figma Link
https://www.figma.com/proto/71GjlkxAtCX1elhz2QARvR/EduPal?node-id=9%3A3&scaling=contain&page-id=9%3A2&starting-point-node-id=9%3A3&show-proto-sidebar=1

# Authors
* Linda Vu
* Harshita Kumar
* Jeremy Ng Kwik Tung
* Aman Khan
* Aditya Vadgama